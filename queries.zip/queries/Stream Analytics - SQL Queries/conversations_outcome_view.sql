drop view Conversations_Outcome_View
go
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Conversations_Outcome_View] 
AS  
select  [dbo].[Steps].convid, 
        [dbo].[Messages].eventtime,
        [dbo].[Steps].steplabel as outcome
FROM [dbo].[Steps]
join [dbo].[Messages] on [dbo].[Messages].convid = [dbo].[Steps].convid 
where [dbo].[Steps].steplabel in ('MSG 1', 'MSG 2', 'MSG 3', 'MSG 4', 'MSG 5', 'MSG 6', 'MSG 7', 'MSG 8', 'MSG 9', 'MSG 10', 'MSG 11', 'MSG 12', 'MSG 13') and 
    not exists (
                        select count(*) as [count], convid from Messages
                        where dialogname like ('%/scenarios/covid19') and eventtype = 'ScenarioStart' and [Messages].convid = [Steps].convid
                        group by convid
                        having count(*) > 1
    )
;
GO